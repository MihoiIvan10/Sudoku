package com.games.soduko;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SodukoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SodukoApplication.class, args);
	}

}
